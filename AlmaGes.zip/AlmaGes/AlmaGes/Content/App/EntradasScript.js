﻿//$(document).ready(function () {
    $(document).on('change', '#codigo', function myfunctio() {

        var url = $("#agregar").attr('data-request-url');
        $.get(url, { producto: $(this).val() }, function (data) {
            $("#descripcion").empty();
            $("#tipo").empty();

            var tipo = data.tipo;
            var descripcion = data.descripcion;
            $("#descripcion").val(descripcion);
            $("#tipo").val(tipo);

        });

    });
//});