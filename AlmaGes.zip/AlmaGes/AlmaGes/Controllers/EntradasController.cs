﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AlmaGes.Models;

namespace AlmaGes.Controllers
{
    [Authorize]
    public class EntradasController : Controller
    {
        private AlmaGesEntities db = new AlmaGesEntities();

        // GET: Entradas
        public ActionResult Index()
        {
            return View(db.Entrada.ToList());
        }

        // GET: Entradas/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Entrada entrada = db.Entrada.Find(id);
            if (entrada == null)
            {
                return HttpNotFound();
            }
            return View(entrada);
        }

        // GET: Entradas/Create
        public ActionResult Create()
        {
            var producto = db.Stock.ToList();
            ViewBag.Producto = new SelectList(producto, "Codigo_Pieza", "Codigo_Pieza");
            return View();
        }

        // POST: Entradas/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create( Entrada entrada)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    db.Entrada.Add(entrada);
                    var sctock = db.Stock.Where(x => x.Codigo_Pieza == entrada.Codigo_Pieza).FirstOrDefault();
                    var disponible = sctock.Cantidad;
                    sctock.Cantidad = disponible + entrada.Cantidad;
                    db.Entry(sctock).State = EntityState.Modified;

                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                catch (Exception)
                {

                    throw;
                }
               
            }

            return View(entrada);
        }

        // GET: Entradas/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Entrada entrada = db.Entrada.Find(id);
            if (entrada == null)
            {
                return HttpNotFound();
            }
            return View(entrada);
        }

        // POST: Entradas/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que desea enlazarse. Para obtener 
        // más información vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "IDEntrada,Codigo_Pieza,Descripcion,Cantidad,Tipo,Fabricante,Distribuidor,Fecha_Entrada")] Entrada entrada)
        {
            if (ModelState.IsValid)
            {
                db.Entry(entrada).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(entrada);
        }

        //// GET: Entradas/Delete/5
        //public ActionResult Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Entrada entrada = db.Entrada.Find(id);
        //    if (entrada == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(entrada);
        //}

        //// POST: Entradas/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    Entrada entrada = db.Entrada.Find(id);
        //    db.Entrada.Remove(entrada);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}
        [HttpGet]
        public JsonResult TiposProducto(string producto)
        {
            db.Configuration.ProxyCreationEnabled = false;
            var productos = db.Stock.Where(x => x.Codigo_Pieza == producto).FirstOrDefault();
            var descripcion = productos.Descripcion;
            var tipo = productos.Tipo;
            return Json(new { descripcion = descripcion, tipo = tipo }, JsonRequestBehavior.AllowGet);
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}






